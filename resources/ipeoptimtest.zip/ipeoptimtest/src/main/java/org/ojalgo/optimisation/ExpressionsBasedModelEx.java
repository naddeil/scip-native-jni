package org.ojalgo.optimisation;

import org.ojalgo.optimisation.Optimisation.Result;

public class ExpressionsBasedModelEx {

	private final ExpressionsBasedModel model;
	private final double cons;
	
	public ExpressionsBasedModelEx(ExpressionsBasedModel model, Double cons) {
		this.model = model;
		this.cons = cons == null ? 0 : cons;
	}
	public ExpressionsBasedModel getModel() {
		return model;
	}
	public Double getCons() {
		return cons;
	}
	
	public Result minimise() {
		ExpressionsBasedModel toOpt = model;
		Result r = toOpt.minimise();
		return Result.of(r.getValue() + cons, r.getState(), r.toRawCopy1D());
	}
	
}
