package org.ojalgo.optimization.solver.scip;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.Optimisation;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.solver.joptimizer.SolverJOptimizer.Configurator;
import org.ojalgo.structure.Access1D;
import org.ojalgo.structure.Structure1D.IntIndex;

import it.prometeia.jscip.SCIP_Vartype;
import it.prometeia.jscip.Scip;
import it.prometeia.jscip.Solution;

public final class SolverScip implements Optimisation.Solver {
    static {
        System.loadLibrary("jscip");
    }

    static final class Integration extends ExpressionsBasedModel.Integration<SolverScip> {

        Integration() {
            super();
        }

        @Override
        public SolverScip build(final ExpressionsBasedModel model) {

            Scip scip = new Scip();
            scip.create("qcqp");

            boolean mip = model.isAnyVariableInteger(); // Variabile indicatrice se il problema contiene anche variabili
                                                        // con vincolo di interezza
            Set<IntIndex> fixed = model.getFixedVariables();

            // Recupero le veriabili del modello
            List<Variable> vars = model.getVariables();
            int nbVars = vars.size();

            // Creo un array di variabili SCIP
            it.prometeia.jscip.Variable[] sVars = new it.prometeia.jscip.Variable[nbVars];

            for (int i = 0; i < nbVars; i++) {

                final Variable mVar = vars.get(i);
                final String name = mVar.getName();
                final double lb = mVar.getLowerLimit(false, Double.NEGATIVE_INFINITY);
                final double ub = mVar.getUpperLimit(false, Double.POSITIVE_INFINITY);

                final SCIP_Vartype type;
                if (mip) {
                    // Se il modello è MIP, allora le variabili sono binarie, intere o continue
                    if (mVar.isBinary()) {
                        type = SCIP_Vartype.SCIP_VARTYPE_BINARY;
                    } else if (mVar.isInteger()) {
                        type = SCIP_Vartype.SCIP_VARTYPE_INTEGER;
                    } else {
                        type = SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS;
                    }
                } else {
                    // Altrimenti solo continue
                    type = SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS;
                }

                // Inizializzo nella funzione obbiettivo il coefficiente 0, lo valorizzerò più
                // avanti
                sVars[i] = scip.createVar(name, lb, ub, 0.0, type);
            }

            // Vado a creare tutti i vincoli del problema
            List<it.prometeia.jscip.Constraint> constraints = model.constraints().map(c -> c.compensate(fixed)).map(mConstr -> buildConstraint(scip, sVars, mConstr))
            .collect(Collectors.toList());

            constraints.forEach(scip::addCons);
            // Recupero la funzione obbiettivo
            final Expression mObj = model.objective().compensate(fixed);
            ExpressionBuilder sObj = ExpressionBuilder.buildExpression(mObj, sVars);
            // Imposta i coefficienti dell'obiettivo
            for (int i = 0; i < sVars.length; i++) {
                final double coef = sObj.getCoefficient(i);
                if (coef != 0.0) {
                    scip.changeVarObj(sVars[i], coef);
                }
            }

            // Infine imposto se sto massimizzando o minimizzando
            if (model.getOptimisationSense() == Optimisation.Sense.MAX) {
                scip.setMaximize();
            } else {
                scip.setMinimize();
            }

            return new SolverScip(scip, sVars,constraints);
        }

        private it.prometeia.jscip.Constraint buildConstraint(Scip scip, it.prometeia.jscip.Variable[] sVars, Expression mConstr) {
            ExpressionBuilder sConstr = ExpressionBuilder.buildExpression(mConstr, sVars);

            // Gestione vincoli speciali (binari/interi)
            if (isSpecialConstraint(mConstr, sVars)) {
                throw new UnsupportedOperationException(
                        "Vincoli speciali (SOS1, SOS2, indicator, etc.) non implementati al momento: " + mConstr);
            }
            // Gestione vincoli quadratici
            else if (sConstr.hasQuadraticTerms()) {
                final double rhs;
                final double lhs;
                final String cName;

                if (mConstr.isEqualityConstraint()) {
                    cName = "qeq_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, 0.0);
                    rhs = mConstr.getLowerLimit(false, 0.0);
                } else if (mConstr.isLowerConstraint()) {
                    cName = "qge_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, Double.NEGATIVE_INFINITY);
                    rhs = scip.infinity();
                } else if (mConstr.isUpperConstraint()) {
                    cName = "qle_" + System.nanoTime();
                    lhs = -scip.infinity();
                    rhs = mConstr.getUpperLimit(false, Double.POSITIVE_INFINITY);
                } else {
                    throw new UnsupportedOperationException(
                            "Vincolo quadratico non gestito: " + mConstr);
                }

                it.prometeia.jscip.Constraint consQuadratic = scip.createConsQuadratic(cName,
                        sConstr.getQuadVars1(),
                        sConstr.getQuadVars2(),
                        sConstr.getQuadCoefs(),
                        sConstr.getLinearVars(),
                        sConstr.getLinearCoefs(),
                        lhs, rhs);
                return consQuadratic;

            } else {
                final double rhs;
                final double lhs;
                final String cName;

                // Gestione vincoli lineari
                if (mConstr.isEqualityConstraint()) {
                    cName = "eq_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, 0.0);
                    rhs = mConstr.getLowerLimit(false, 0.0);
                } else if (mConstr.isLowerConstraint()) {
                    cName = "ge_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, Double.NEGATIVE_INFINITY);
                    rhs = scip.infinity();
                } else if (mConstr.isUpperConstraint()) {
                    cName = "le_" + System.nanoTime();
                    lhs = -scip.infinity();
                    rhs = mConstr.getUpperLimit(false, Double.POSITIVE_INFINITY);
                } else {
                    throw new UnsupportedOperationException("Vincolo lineare non gestito: " + mConstr);
                }

                it.prometeia.jscip.Constraint consLinear = scip.createConsLinear(cName,
                        sConstr.getLinearVars(), sConstr.getLinearCoefs(),
                        lhs, rhs);
                return consLinear;
            }
        }

        @Override
        public boolean isCapable(final ExpressionsBasedModel model) {
            // TODO: non capable se ci sono vincoli binari/interi
            // JSCIPOpt non supporta problemi con obiettivi quadratici
            return !model.isAnyObjectiveQuadratic();
        }

        private boolean isSpecialConstraint(Expression constraint, it.prometeia.jscip.Variable[] variables) {
            // Controlla se è un vincolo che richiede gestione speciale (SOS1, SOS2,
            // indicator, etc.)
            // Per ora implementiamo la logica di base per vincoli binari/interi

            if (constraint.isEqualityConstraint() && hasOnlyBinaryVariables(constraint, variables)) {
                return true; // Potrebbe essere un vincolo di set partitioning
            }

            return false;
        }

        private boolean hasOnlyBinaryVariables(Expression constraint, it.prometeia.jscip.Variable[] variables) {
            for (IntIndex key : constraint.getLinearKeySet()) {
                if (variables[key.index].getType() != SCIP_Vartype.SCIP_VARTYPE_BINARY) {
                    return false;
                }
            }
            return true;
        }
    }

    public static final ExpressionsBasedModel.Integration<SolverScip> INTEGRATION = new Integration();

    static final Configurator DEFAULT = new Configurator();

    // scip
    private final Scip scip;
    private final List<it.prometeia.jscip.Variable> variables;
    private final List<it.prometeia.jscip.Constraint> constraints;

    SolverScip(
            final Scip scip, it.prometeia.jscip.Variable[] variables, List<it.prometeia.jscip.Constraint> constraints) {
        super();
        this.scip = scip;
        this.variables = Arrays.asList(variables);
        this.constraints = constraints;
    }

    @Override
    public Result solve(final Result kickStarter) {

        // Configurator configurator =
        // myOptions.getConfigurator(Configurator.class).orElse(DEFAULT);
        //
        // OptimizationRequestHandler handler =
        // configurator.newOptimizationRequestHandler(myRequest);
        //
        // configurator.configure(myRequest, handler, myOptions);

        Optimisation.State retState = Optimisation.State.UNEXPLORED;
        Access1D<Double> retSolution = null;

        // if (kickStarter != null && kickStarter.getState().isFeasible()) {
        // retState = kickStarter.getState();
        // myRequest.setInitialPoint(kickStarter.toRawCopy1D());
        // }

        try {

            scip.solve();
            final Solution sol = scip.getBestSol();
            final it.prometeia.jscip.SCIP_Status status = scip.getStatus();

            if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_OPTIMAL) {
                retState = Optimisation.State.OPTIMAL;
                double[] solution = new double[variables.size()];
                for (int i = 0; i < variables.size(); i++) {
                    solution[i] = scip.getSolVal(sol, variables.get(i));
                }
                retSolution = Access1D.wrap(solution);
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_INFEASIBLE) {
                retState = Optimisation.State.INFEASIBLE;
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_UNBOUNDED) {
                retState = Optimisation.State.UNBOUNDED;
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_INFORUNBD) {
                retState = Optimisation.State.UNBOUNDED;
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_TIMELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_MEMLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_NODELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_TOTALNODELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_STALLNODELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_GAPLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_SOLLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_BESTSOLLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_RESTARTLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_USERINTERRUPT) {
                retState = Optimisation.State.FAILED;
            } else {
                retState = Optimisation.State.FAILED;
            }

        } catch (Exception cause) {

            retState = Optimisation.State.FAILED;

        } finally {

            if (retSolution == null && kickStarter != null) {
                retSolution = Access1D.wrap(kickStarter.toRawCopy1D());
            }

            for (it.prometeia.jscip.Variable var : variables) {
                scip.releaseVar(var);
            }

            for (it.prometeia.jscip.Constraint constraint : constraints) {
                scip.releaseCons(constraint);
            }
            
            scip.free();

        }

        return new Optimisation.Result(retState, retSolution);
    }

}
