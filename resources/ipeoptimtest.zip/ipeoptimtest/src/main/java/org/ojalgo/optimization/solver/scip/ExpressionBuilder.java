package org.ojalgo.optimization.solver.scip;

import java.util.ArrayList;
import java.util.List;

import org.ojalgo.optimisation.Expression;
import org.ojalgo.structure.Structure1D.IntIndex;
import org.ojalgo.structure.Structure2D.IntRowColumn;

public class ExpressionBuilder {
    private final List<it.prometeia.jscip.Variable> linearVars = new ArrayList<>();
    private final List<Double> linearCoefs = new ArrayList<>();
    private final List<it.prometeia.jscip.Variable> quadVars1 = new ArrayList<>();
    private final List<it.prometeia.jscip.Variable> quadVars2 = new ArrayList<>();
    private final List<Double> quadCoefs = new ArrayList<>();
    private final double[] coefficients;


    static ExpressionBuilder buildExpression(final Expression expression, final it.prometeia.jscip.Variable[] variables) {

        ExpressionBuilder builder = new ExpressionBuilder(variables.length);

        if (expression.isFunctionQuadratic()) {
            copyQuadratic(expression, variables, builder);
            copyLinear(expression, variables, builder);
        } else if (expression.isFunctionPureQuadratic()) {
            copyQuadratic(expression, variables, builder);
        } else if (expression.isFunctionLinear()) {
            copyLinear(expression, variables, builder);
        }

        return builder;
    }

    private static void copyLinear(final Expression source, final it.prometeia.jscip.Variable[] variables,
            final ExpressionBuilder destination) {
        for (IntIndex key : source.getLinearKeySet()) {
            destination.addLinearTerm(source.doubleValue(key, false), variables[key.index], key.index);
        }
    }

    private static void copyQuadratic(final Expression source, final it.prometeia.jscip.Variable[] variables,
            final ExpressionBuilder destination) {
        for (IntRowColumn key : source.getQuadraticKeySet()) {
            destination.addQuadraticTerm(source.doubleValue(key, false), variables[key.row],
                    variables[key.column]);
        }
    }

    public ExpressionBuilder(int numVars) {
        this.coefficients = new double[numVars];
    }

    public void addLinearTerm(double coef, it.prometeia.jscip.Variable var, int varIndex) {
        if (coef != 0.0) {
            linearVars.add(var);
            linearCoefs.add(coef);
            coefficients[varIndex] = coef;
        }
    }

    public void addQuadraticTerm(double coef, it.prometeia.jscip.Variable var1, it.prometeia.jscip.Variable var2) {
        if (coef != 0.0) {
            quadVars1.add(var1);
            quadVars2.add(var2);
            quadCoefs.add(coef);
        }
    }

    public it.prometeia.jscip.Variable[] getLinearVars() {
        return linearVars.toArray(new it.prometeia.jscip.Variable[0]);
    }

    public double[] getLinearCoefs() {
        return linearCoefs.stream().mapToDouble(Double::doubleValue).toArray();
    }

    public it.prometeia.jscip.Variable[] getQuadVars1() {
        return quadVars1.toArray(new it.prometeia.jscip.Variable[0]);
    }

    public it.prometeia.jscip.Variable[] getQuadVars2() {
        return quadVars2.toArray(new it.prometeia.jscip.Variable[0]);
    }

    public double[] getQuadCoefs() {
        return quadCoefs.stream().mapToDouble(Double::doubleValue).toArray();
    }

    public double getCoefficient(int index) {
        return coefficients[index];
    }

    public boolean hasQuadraticTerms() {
        return !quadVars1.isEmpty();
    }


}