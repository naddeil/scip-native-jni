package org.ojalgo.optimization.solver.scip;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.Optimisation;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.optimisation.solver.joptimizer.SolverJOptimizer.Configurator;
import org.ojalgo.structure.Access1D;
import org.ojalgo.structure.Structure1D.IntIndex;

import it.prometeia.jscip.SCIP_Vartype;
import it.prometeia.jscip.Scip;

public final class SolverScipQuad implements Optimisation.Solver {
    static {
        System.loadLibrary("jscip");
    }

    static final class Integration extends ExpressionsBasedModel.Integration<SolverScipQuad> {

        Integration() {
            super();
        }

        @Override
        public SolverScipQuad build(final ExpressionsBasedModel model) {

            // Configurator configurator =
            // model.options.getConfigurator(Configurator.class).orElse(DEFAULT);

            Scip scip = new Scip();
            scip.create("qcqp" + System.nanoTime());

            scip.setIntParam("display/verblevel", 0); // no log

            boolean mip = model.isAnyVariableInteger(); // Variabile indicatrice se il problema contiene anche variabili
                                                        // con vincolo di interezza
            Set<IntIndex> fixed = model.getFixedVariables();

            // Recupero le veriabili del modello
            List<Variable> vars = model.getVariables();
            int nbVars = vars.size();

            // Creo un array di variabili SCIP
            it.prometeia.jscip.Variable[] sVars = new it.prometeia.jscip.Variable[nbVars];

            for (int i = 0; i < nbVars; i++) {

                final Variable mVar = vars.get(i);
                final String name = mVar.getName();
                final double lb = mVar.getLowerLimit(false, Double.NEGATIVE_INFINITY);
                final double ub = mVar.getUpperLimit(false, Double.POSITIVE_INFINITY);

                final SCIP_Vartype type;
                if (mip) {
                    // Se il modello è MIP, allora le variabili sono binarie, intere o continue
                    if (mVar.isBinary()) {
                        type = SCIP_Vartype.SCIP_VARTYPE_BINARY;
                    } else if (mVar.isInteger()) {
                        type = SCIP_Vartype.SCIP_VARTYPE_INTEGER;
                    } else {
                        type = SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS;
                    }
                } else {
                    // Altrimenti solo continue
                    type = SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS;
                }

                // Inizializzo nella funzione obbiettivo il coefficiente 0, lo valorizzerò più
                // avanti
                sVars[i] = scip.createVar(name, lb, ub, 0.0, type);
            }

            // Vado a creare tutti i vincoli del problema
            List<it.prometeia.jscip.Constraint> constraints = model.constraints().map(c -> c.compensate(fixed))
                    .map(mConstr -> buildConstraint(scip, sVars, mConstr))
                    .collect(Collectors.toCollection(ArrayList::new));

            // Li aggiungo al solver SCIP
            constraints.forEach(scip::addCons);

            // Recupero la funzione obbiettivo
            final Expression mObj = model.objective().compensate(fixed);
            ExpressionBuilder sObj = ExpressionBuilder.buildExpression(mObj, sVars);
            Optimisation.Sense sense = model.getOptimisationSense();

            // Trasforma obiettivo quadratico usando variabile ausiliaria
            it.prometeia.jscip.Variable quadAuxVar = null;
            try {
                quadAuxVar = transformQuadraticObjective(mObj, scip, sVars, sense, constraints);
            } catch (Exception e) {
                e.printStackTrace();
            }
            List<it.prometeia.jscip.Variable> auxVars = new ArrayList<>();
            // Se quadAuxVar != null, i coefficienti sono già stati impostati in
            // transformQuadraticObjective
            if (quadAuxVar == null) {
                // Obiettivo lineare - gestione normale
                for (int i = 0; i < sVars.length; i++) {
                    double coef = sObj.getCoefficient(i);
                    if (coef != 0.0) {
                        scip.changeVarObj(sVars[i], coef);
                    }
                }
            }else{
                auxVars.add(quadAuxVar);
            }

            // Infine imposto se sto massimizzando o minimizzando
            if (sense == Optimisation.Sense.MAX) {
                scip.setMaximize();
            } else {
                scip.setMinimize();
            }

            return new SolverScipQuad(scip, sVars, constraints, auxVars);
        }

        /**
         * Versione alternativa che forza l'uguaglianza (più precisa ma potenzialmente
         * più lenta)
         */
        private it.prometeia.jscip.Variable transformQuadraticObjectiveWithEquality(Expression objective, Scip solver,
                it.prometeia.jscip.Variable[] variables) throws Exception {
            ExpressionBuilder objectiveFunctionConstraintBuilder = ExpressionBuilder.buildExpression(objective,
                    variables);
            if (!objectiveFunctionConstraintBuilder.hasQuadraticTerms()) {
                return null;
            }

            // Crea variabile ausiliaria, la variabile è continua ha coeffieciente 1 nella
            // funzione obbiettivo e non ha limiti
            String auxVarName = "quad_aux_obj_eq_" + System.nanoTime();
            it.prometeia.jscip.Variable quadAuxVar = solver.createVar(auxVarName,
                    -solver.infinity(), solver.infinity(), 1.0, SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS);

            // Aggiungo alla parte lineare della funzione obbiettivo la variabile ausiliaria
            it.prometeia.jscip.Variable[] consVars = new it.prometeia.jscip.Variable[objectiveFunctionConstraintBuilder.getLinearVars().length
                    + 1];
            double[] consCoefs = new double[objectiveFunctionConstraintBuilder.getLinearCoefs().length + 1];

            // la variabile ausiliaria ha coefficiente 1
            consVars[0] = quadAuxVar;
            consCoefs[0] = 1.0;

            // neghiamo i coeffiecenti della parte lineare per creare un vincolo di
            // uguaglianza
            System.arraycopy(objectiveFunctionConstraintBuilder.getLinearVars(), 0, consVars, 1,
                    objectiveFunctionConstraintBuilder.getLinearVars().length);
            for (int i = 0; i < objectiveFunctionConstraintBuilder.getLinearCoefs().length; i++) {
                consCoefs[i + 1] = -objectiveFunctionConstraintBuilder.getLinearCoefs()[i];
            }

            // neghiamo i coeffiecenti della parte quadratica per creare un vincolo di
            // uguaglianza
            solver.addCons(solver.createConsQuadratic("quad_obj_eq_constraint",
                    objectiveFunctionConstraintBuilder.getQuadVars1(),
                    objectiveFunctionConstraintBuilder.getQuadVars2(),
                    negateCoefficients(objectiveFunctionConstraintBuilder.getQuadCoefs()),
                    consVars, consCoefs,
                    0.0, 0.0));

            return quadAuxVar;
        }

        private it.prometeia.jscip.Constraint buildConstraint(Scip scip, it.prometeia.jscip.Variable[] sVars, Expression mConstr) {
            ExpressionBuilder sConstr = ExpressionBuilder.buildExpression(mConstr, sVars);
            // Gestione vincoli speciali (binari/interi)
            if (isSpecialConstraint(mConstr, sVars)) {
                throw new UnsupportedOperationException(
                        "Vincoli speciali (SOS1, SOS2, indicator, etc.) non implementati al momento: "
                                + mConstr);

            }
            // Gestione vincoli quadratici
            else if (sConstr.hasQuadraticTerms()) {
                final double rhs;
                final double lhs;
                final String cName;

                if (mConstr.isEqualityConstraint()) {
                    cName = "qeq_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, 0.0);
                    rhs = mConstr.getLowerLimit(false, 0.0);
                } else if (mConstr.isLowerConstraint()) {
                    cName = "qge_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, Double.NEGATIVE_INFINITY);
                    rhs = scip.infinity();
                } else if (mConstr.isUpperConstraint()) {
                    cName = "qle_" + System.nanoTime();
                    lhs = -scip.infinity();
                    rhs = mConstr.getUpperLimit(false, Double.POSITIVE_INFINITY);
                } else {
                    throw new UnsupportedOperationException(
                            "Vincolo quadratico non gestito: " + mConstr);
                }

                it.prometeia.jscip.Constraint consQuadratic = scip.createConsQuadratic(cName,
                        sConstr.getQuadVars1(),
                        sConstr.getQuadVars2(),
                        sConstr.getQuadCoefs(),
                        sConstr.getLinearVars(),
                        sConstr.getLinearCoefs(),
                        lhs, rhs);
                return consQuadratic;
            } else {
                final double rhs;
                final double lhs;
                final String cName;

                // Gestione vincoli lineari
                if (mConstr.isEqualityConstraint()) {
                    cName = "eq_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, 0.0);
                    rhs = mConstr.getLowerLimit(false, 0.0);
                } else if (mConstr.isLowerConstraint()) {
                    cName = "ge_" + System.nanoTime();
                    lhs = mConstr.getLowerLimit(false, Double.NEGATIVE_INFINITY);
                    rhs = scip.infinity();
                } else if (mConstr.isUpperConstraint()) {
                    cName = "le_" + System.nanoTime();
                    lhs = -scip.infinity();
                    rhs = mConstr.getUpperLimit(false, Double.POSITIVE_INFINITY);
                } else {
                    throw new UnsupportedOperationException("Vincolo lineare non gestito: " + mConstr);
                }

                it.prometeia.jscip.Constraint consLinear = scip.createConsLinear(cName,
                        sConstr.getLinearVars(), sConstr.getLinearCoefs(),
                        lhs, rhs);
                return consLinear;
            }
        }

        @Override
        public boolean isCapable(final ExpressionsBasedModel model) {
            // TODO: non capable se ci sono vincoli binari/interi
            return true;
        }

        private boolean isSpecialConstraint(Expression constraint, it.prometeia.jscip.Variable[] variables) {
            // Controlla se è un vincolo che richiede gestione speciale (SOS1, SOS2,
            // indicator, etc.)
            // Per ora implementiamo la logica di base per vincoli binari/interi

            if (constraint.isEqualityConstraint() && hasOnlyBinaryVariables(constraint, variables)) {
                return true; // Potrebbe essere un vincolo di set partitioning
            }

            return false;
        }

        private boolean hasOnlyBinaryVariables(Expression constraint, it.prometeia.jscip.Variable[] variables) {
            for (IntIndex key : constraint.getLinearKeySet()) {
                if (variables[key.index].getType() != SCIP_Vartype.SCIP_VARTYPE_BINARY) {
                    return false;
                }
            }
            return true;
        }

        /**
         * Trasforma la funzione obiettivo quadratica in vincoli quadratici usando
         * variabile ausiliaria
         * 
         * @param objective L'espressione obiettivo originale
         * @param solver    Il solver SCIP
         * @param variables Le variabili del problema
         * @param sense     Il senso di ottimizzazione
         * @return La variabile ausiliaria creata (null se obiettivo non quadratico)
         */
        private it.prometeia.jscip.Variable transformQuadraticObjective(Expression objective, Scip solver,
                it.prometeia.jscip.Variable[] variables,
                Optimisation.Sense sense, List<it.prometeia.jscip.Constraint> constraints) throws Exception {
            ExpressionBuilder objBuilder = ExpressionBuilder.buildExpression(objective, variables);
            if (!objBuilder.hasQuadraticTerms()) {
                // Obiettivo lineare - gestione normale
                for (int i = 0; i < variables.length; i++) {
                    double coef = objBuilder.getCoefficient(i);
                    if (coef != 0.0) {
                        solver.changeVarObj(variables[i], coef);
                    }
                }
                return null;
            }

            // Obiettivo quadratico - crea variabile ausiliaria
            String auxVarName = "quad_aux_obj_" + System.nanoTime();
            it.prometeia.jscip.Variable quadAuxVar;

            if (sense == Optimisation.Sense.MIN) {
                // Minimizzazione: aux_var ≥ funzione_quadratica
                quadAuxVar = solver.createVar(auxVarName,
                        -solver.infinity(), solver.infinity(), 1.0, SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS);

                // Vincolo: aux_var - funzione_quadratica ≥ 0
                // Riorganizzato: aux_var ≥ parte_lineare + parte_quadratica
                it.prometeia.jscip.Variable[] consVars = new it.prometeia.jscip.Variable[objBuilder.getLinearVars().length + 1];
                double[] consCoefs = new double[objBuilder.getLinearCoefs().length + 1];

                // Variabile ausiliaria con coefficiente +1
                consVars[0] = quadAuxVar;
                consCoefs[0] = 1.0;

                // Variabili lineari con coefficienti negati
                System.arraycopy(objBuilder.getLinearVars(), 0, consVars, 1, objBuilder.getLinearVars().length);
                for (int i = 0; i < objBuilder.getLinearCoefs().length; i++) {
                    consCoefs[i + 1] = -objBuilder.getLinearCoefs()[i];
                }

                // Crea vincolo quadratico: aux_var - parte_lineare - parte_quadratica ≥ 0
                it.prometeia.jscip.Constraint consQuadratic = solver.createConsQuadratic("quad_obj_min_constraint",
                        objBuilder.getQuadVars1(), objBuilder.getQuadVars2(),
                        negateCoefficients(objBuilder.getQuadCoefs()),
                        consVars, consCoefs,
                        0.0, solver.infinity());
                constraints.add(consQuadratic);
                solver.addCons(consQuadratic);

            } else {
                // Massimizzazione: aux_var ≤ funzione_quadratica
                quadAuxVar = solver.createVar(auxVarName,
                        -solver.infinity(), solver.infinity(), 1.0, SCIP_Vartype.SCIP_VARTYPE_CONTINUOUS);

                // Vincolo: aux_var - funzione_quadratica ≤ 0
                it.prometeia.jscip.Variable[] consVars = new it.prometeia.jscip.Variable[objBuilder.getLinearVars().length + 1];
                double[] consCoefs = new double[objBuilder.getLinearCoefs().length + 1];

                // Variabile ausiliaria con coefficiente +1
                consVars[0] = quadAuxVar;
                consCoefs[0] = 1.0;

                // Variabili lineari con coefficienti negati
                System.arraycopy(objBuilder.getLinearVars(), 0, consVars, 1, objBuilder.getLinearVars().length);
                for (int i = 0; i < objBuilder.getLinearCoefs().length; i++) {
                    consCoefs[i + 1] = -objBuilder.getLinearCoefs()[i];
                }

                // Crea vincolo quadratico: aux_var - parte_lineare - parte_quadratica ≤ 0
                it.prometeia.jscip.Constraint consQuadratic = solver.createConsQuadratic("quad_obj_max_constraint",
                        objBuilder.getQuadVars1(), objBuilder.getQuadVars2(),
                        negateCoefficients(objBuilder.getQuadCoefs()),
                        consVars, consCoefs,
                        -solver.infinity(), 0.0);
                constraints.add(consQuadratic);
                solver.addCons(consQuadratic);
            }

            return quadAuxVar;
        }

        private double[] negateCoefficients(double[] coefficients) {
            double[] negated = new double[coefficients.length];
            for (int i = 0; i < coefficients.length; i++) {
                negated[i] = -coefficients[i];
            }
            return negated;
        }
    }

    public static final ExpressionsBasedModel.Integration<SolverScipQuad> INTEGRATION = new Integration();

    static final Configurator DEFAULT = new Configurator();

    // scip
    private final Scip scip;
    private final List<it.prometeia.jscip.Variable> variables;
    private final List<it.prometeia.jscip.Constraint> constraints;
    private final List<it.prometeia.jscip.Variable> auxVars;

    SolverScipQuad(
            final Scip scip, it.prometeia.jscip.Variable[] variables, List<it.prometeia.jscip.Constraint> constraints, List<it.prometeia.jscip.Variable> auxVars) {
        super();
        this.scip = scip;
        this.variables = Arrays.asList(variables);
        this.constraints = constraints;
        this.auxVars = auxVars;
    }

    @Override
    public Result solve(final Result kickStarter) {

        // Configurator configurator =
        // myOptions.getConfigurator(Configurator.class).orElse(DEFAULT);
        //
        // OptimizationRequestHandler handler =
        // configurator.newOptimizationRequestHandler(myRequest);
        //
        // configurator.configure(myRequest, handler, myOptions);

        Optimisation.State retState = Optimisation.State.UNEXPLORED;
        Access1D<Double> retSolution = null;

        // if (kickStarter != null && kickStarter.getState().isFeasible()) {
        // retState = kickStarter.getState();
        // myRequest.setInitialPoint(kickStarter.toRawCopy1D());
        // }

        try {

            scip.solve();
            final var sol = scip.getBestSol();
            final it.prometeia.jscip.SCIP_Status status = scip.getStatus();

            if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_OPTIMAL) {
                retState = Optimisation.State.OPTIMAL;
                double[] solution = new double[variables.size()];
                for (int i = 0; i < variables.size(); i++) {
                    solution[i] = scip.getSolVal(sol, variables.get(i));
                }
                retSolution = Access1D.wrap(solution);
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_INFEASIBLE) {
                retState = Optimisation.State.INFEASIBLE;
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_UNBOUNDED) {
                retState = Optimisation.State.UNBOUNDED;
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_INFORUNBD) {
                retState = Optimisation.State.UNBOUNDED;
            } else if (status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_TIMELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_MEMLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_NODELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_TOTALNODELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_STALLNODELIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_GAPLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_SOLLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_BESTSOLLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_RESTARTLIMIT ||
                    status == it.prometeia.jscip.SCIP_Status.SCIP_STATUS_USERINTERRUPT) {
                retState = Optimisation.State.FAILED;
            } else {
                retState = Optimisation.State.FAILED;
            }

        } catch (Exception cause) {

            retState = Optimisation.State.FAILED;

        } finally {

            if (retSolution == null && kickStarter != null) {
                retSolution = Access1D.wrap(kickStarter.toRawCopy1D());
            }

            for (it.prometeia.jscip.Variable var : variables) {
                scip.releaseVar(var);
            }

            for (it.prometeia.jscip.Constraint constraint : constraints) {
                scip.releaseCons(constraint);
            }
            for (it.prometeia.jscip.Variable auxVar : auxVars) {
                scip.releaseVar(auxVar);
            }
            scip.free();

        }

        return new Optimisation.Result(retState, retSolution);
    }

}
