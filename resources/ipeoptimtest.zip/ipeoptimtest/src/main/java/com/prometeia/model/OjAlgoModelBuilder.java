package com.prometeia.model;


import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.log4j.Logger;
import org.ojalgo.optimisation.Expression;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.ExpressionsBasedModelEx;
import org.ojalgo.optimisation.Variable;
import org.ojalgo.structure.Structure1D.IntIndex;
import org.ojalgo.structure.Structure2D.IntRowColumn;


public class OjAlgoModelBuilder {

	// F.O (M^T * x - y)^T * QQ * (M^T * x - y)
	public static ExpressionsBasedModelEx buildModel_minTev(OjProblem problem) {

	    // Dati standard
	    RealMatrix G = problem.getG();
	    RealVector h = problem.getH();
	    RealMatrix A = problem.getA();
	    RealVector b = problem.getB();
	    RealVector lb = problem.getLb();
	    RealVector ub = problem.getUb();
	    List<RealMatrix> Q_i = problem.getQ_i();
	    List<RealVector> p_i = problem.getP_i();
	    List<Double> r_i = problem.getR_i();

	    // f.o in formato min (M^T * x - y)^T * QQ * (M^T * x - y)
	    RealMatrix M = problem.getM();
	    RealVector y = problem.getY();
	    RealMatrix S = problem.getS();

	    // Dimensione
	    int n = (M != null ? M.getRowDimension() : 0);

	    ExpressionsBasedModel model = new ExpressionsBasedModel();

	    // Variabili
	    for (int i = 0; i < n; i++) {
	        Variable var = model.addVariable("x" + i);
	        if (lb != null) {
	        	var.lower(lb.getEntry(i));
	        }
	        if (ub != null) {
	        	var.upper(ub.getEntry(i));
	        }
	    }

	    //riscrivo l'f.o (M^T * x - y)^T * S * (M^T * x - y) per tornare a 1/2 x^T Q_eff x + p_eff^T x + r_eff
	    //(M^T x - y)^T * S * (M^T x - y) = x^T(M S M^T)x - 2(M S y)^T + y^T S y
	   
	    //Q_eff = 2 * (M S M^T)
	    //p_eff = - 2(M S y)
	    //r_ff = y^T S y
	    

	    RealMatrix Qeff = M.multiply(S).multiply(M.transpose()); //.scalarMultiply(2.0); // M^T S M (attenzione, senza il 2* )
	    RealVector peff = M.multiply(S).operate(y).mapMultiply(-2.0);        // -2 M S y
	    double reff = y.dotProduct(S.operate(y));

	    // Funzione obiettivo
	    Expression obj = model.addExpression("objective").weight(1.0);

	    // Termini quadratici da Qeff
	    for (int i = 0; i < n; i++) {
	        for (int j = 0; j < n; j++) {
	            double val = Qeff.getEntry(i, j);
	            if (val != 0.0) {
	                obj.set(model.getVariable(i), model.getVariable(j), val); // visto che i coeff di Q vanno dati 1/2, non metto il 2* qui (alternativa allo scalarMultiply sopra)!
	            }
	        }
	    }

	    // Termini lineari da peff
	    for (int i = 0; i < n; i++) {
	        double val = peff.getEntry(i);
	        if (val != 0.0) {
	            obj.set(model.getVariable(i), val);
	        }
	    }
	    
        if (reff != 0) {
 //       	obj.set(model.addVariable("r").lower(1.0).upper(1.0).weight(0.0), reff);
      }

        // 3. Vincoli di uguaglianza: Ax = b
        if (A != null && b != null) {
            int m = A.getRowDimension();
            for (int row = 0; row < m; row++) {
                Expression eq = model.addExpression("eq_" + row).level(b.getEntry(row));
                for (int col = 0; col < n; col++) {
                    eq.set(model.getVariable(col), A.getEntry(row, col));
                }
            }
        }

        // 4. Vincoli di disuguaglianza lineari: Gx <= h
        if (G != null && h != null) {
            int m = G.getRowDimension();
            for (int row = 0; row < m; row++) {
                Expression ineq = model.addExpression("ineq_" + row).upper(h.getEntry(row));
                for (int col = 0; col < n; col++) {
                    ineq.set(model.getVariable(col), G.getEntry(row, col));
                }
            }
        }

        // 5. Vincoli quadratici: 1/2 x^T Q_i x + p_i^T x + r_i <= 0
        if (Q_i != null && p_i != null && r_i != null &&
            Q_i.size() == p_i.size() && p_i.size() == r_i.size()) {

            for (int k = 0; k < Q_i.size(); k++) {
                Expression qConstr = model.addExpression("qc_" + k).upper(-r_i.get(k));

                RealMatrix Qi = Q_i.get(k);
                RealVector pi = p_i.get(k);

                // Termini quadratici
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        double val = Qi.getEntry(i, j);
                        if (val != 0.0) {
                            qConstr.set(model.getVariable(i), model.getVariable(j), APPLICA_12 ? (0.5 * val) : val);//applica 0.5 alla Qi
                        }
                    }
                }

                // Termini lineari
                for (int i = 0; i < n; i++) {
                    double val = pi.getEntry(i);
                    if (val != 0.0) {
                        qConstr.set(model.getVariable(i), val);
                    }
                }
            }
        }

	    return new ExpressionsBasedModelEx(model, reff);
	}
	
	
	private final static boolean APPLICA_12 = true; //non toccare, deve stare a true!!

    
	//crea una f.o in modo che f(x) = 1/2 x^T Q x + p^T x + r
	//si fa dividendo la Q originale per 1/2, come i vincoli quadratici, perche' gli ottimizzatori sotto in realtà trattano x^T Q x
    public static ExpressionsBasedModelEx buildModel12q_p_r(OjProblem problem) {

        RealMatrix Q = problem.getQ();
        RealVector p = problem.getP();
        Double r = problem.getR();

        RealMatrix G = problem.getG();
        RealVector h = problem.getH();

        RealMatrix A = problem.getA();
        RealVector b = problem.getB();

        RealVector lb = problem.getLb();
        RealVector ub = problem.getUb();

        List<RealMatrix> Q_i = problem.getQ_i();
        List<RealVector> p_i = problem.getP_i();
        List<Double> r_i = problem.getR_i();

        int n = (p != null) ? p.getDimension() :
                (Q != null ? Q.getColumnDimension() :
                 (A != null ? A.getColumnDimension() : 0));

        ExpressionsBasedModel model = new ExpressionsBasedModel();

        // 1. Variabili
        for (int i = 0; i < n; i++) {
            Variable var = model.addVariable("x" + i);
            if (lb != null) var.lower(lb.getEntry(i));
            if (ub != null) var.upper(ub.getEntry(i));
        }

        // 2. Funzione obiettivo 1/2 x^T Q x + p^T x + r <= 0
        Expression objExpr = model.addExpression("objective").weight(1.0);

        if (Q != null) {
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < n; j++) {
                    double qVal = Q.getEntry(i, j);
                    if (qVal != 0.0) {
                        objExpr.set(model.getVariable(i), model.getVariable(j), APPLICA_12 ? (0.5 * qVal) : qVal); //applica 0.5 alla Q, nella matrice i fattori non devono gia' essere adattati
                    }
                }
            }
        }

        if (p != null) {
            for (int i = 0; i < n; i++) {
                double pi = p.getEntry(i);
                if (pi != 0.0) {
                    objExpr.set(model.getVariable(i), pi);
                }
            }
        }

        if (r != null) {
 //           objExpr.set(model.addVariable("r").lower(1.0).upper(1.0).weight(0.0), r);
        }

        // 3. Vincoli di uguaglianza: Ax = b
        if (A != null && b != null) {
            int m = A.getRowDimension();
            for (int row = 0; row < m; row++) {
                Expression eq = model.addExpression("eq_" + row).level(b.getEntry(row));
                for (int col = 0; col < n; col++) {
                    eq.set(model.getVariable(col), A.getEntry(row, col));
                }
            }
        }

        // 4. Vincoli di disuguaglianza lineari: Gx <= h
        if (G != null && h != null) {
            int m = G.getRowDimension();
            for (int row = 0; row < m; row++) {
                Expression ineq = model.addExpression("ineq_" + row).upper(h.getEntry(row));
                for (int col = 0; col < n; col++) {
                    ineq.set(model.getVariable(col), G.getEntry(row, col));
                }
            }
        }

        // 5. Vincoli quadratici: 1/2 x^T Q_i x + p_i^T x + r_i <= 0
        if (Q_i != null && p_i != null && r_i != null &&
            Q_i.size() == p_i.size() && p_i.size() == r_i.size()) {

            for (int k = 0; k < Q_i.size(); k++) {
                Expression qConstr = model.addExpression("qc_" + k).upper(-r_i.get(k));

                RealMatrix Qi = Q_i.get(k);
                RealVector pi = p_i.get(k);

                // Termini quadratici
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        double val = Qi.getEntry(i, j);
                        if (val != 0.0) {
                            qConstr.set(model.getVariable(i), model.getVariable(j), APPLICA_12 ? (0.5 * val) : val);//applica 0.5 alla Qi
                        }
                    }
                }

                // Termini lineari
                for (int i = 0; i < n; i++) {
                    double val = pi.getEntry(i);
                    if (val != 0.0) {
                        qConstr.set(model.getVariable(i), val);
                    }
                }
            }
        }
        
        //TODO Capire se va bene
        //da NumberContext
        //    private static final int DEFAULT_SCALE = Integer.MIN_VALUE;
        //per evitare 
        // org.ojalgo.type.context.NumberContext.scale(BigDecimal)
        //model.options.solution = NumberContext.of(14,Integer.MIN_VALUE);
//        model.options.logger_detailed = true;

        return new ExpressionsBasedModelEx(model, r);
    }
  
    public static void printModelDetails(Logger logger, String title, ExpressionsBasedModel model) {
        StringBuilder sb = new StringBuilder();

        List<Variable> vars = model.getVariables();
        int n = vars.size();

        sb.append("\n");
        sb.append(": Problema "+title+"\n");
        sb.append("  min ½ xᵀQx + pᵀx + r\n");

        Expression obj = model.objective();

        double[][] Q = new double[n][n];
        double[] p = new double[n];

        // Parte lineare
        for (Map.Entry<IntIndex, BigDecimal> entry : obj.getLinearEntrySet()) {
            int i = entry.getKey().index;
            p[i] = entry.getValue().doubleValue();
        }

        // Parte quadratica
        for (Map.Entry<IntRowColumn, BigDecimal> entry : obj.getQuadraticEntrySet()) {
            int i = entry.getKey().row;
            int j = entry.getKey().column;
            Q[i][j] = APPLICA_12 ? (entry.getValue().doubleValue() * 2) : entry.getValue().doubleValue(); //rimetto il *2 che era stato tolto nella creazione del modello
        }

        sb.append("  Q =\n");
        appendMatrix(sb, Q);

        sb.append("  p =\n");
        appendVector(sb, p);

        // Variabili
        sb.append("\n:Variabili\n");
        for (int i = 0; i < n; ++i) {
            Variable v = vars.get(i);
            sb.append("  [" + i + "] : " + v.getName());
            if (v.isBinary()) {
            	sb.append(" [binary]");
            }
            if (checkIfFixed(v)) {
            	sb.append(" >>>FIXED<<< => " + v.getValue());
            }
            sb.append("\n");
        }

        // Classificazione vincoli
        List<Expression> ineqsLE = model.getExpressions().stream()
                .filter(e -> !e.isEqualityConstraint() && e.isConstraint()
                        && e.getUpperLimit() != null && e.getLowerLimit() == null
                        && !e.isAnyQuadraticFactorNonZero() && !e.isObjective())
                .collect(Collectors.toList());

        List<Expression> ineqsGE = model.getExpressions().stream()
                .filter(e -> !e.isEqualityConstraint() && e.isConstraint()
                        && e.getUpperLimit() == null && e.getLowerLimit() != null
                        && !e.isAnyQuadraticFactorNonZero() && !e.isObjective())
                .collect(Collectors.toList());

        List<Expression> eqs = model.getExpressions().stream()
                .filter(e -> e.isEqualityConstraint() && e.isConstraint()
                        && !e.isAnyQuadraticFactorNonZero() && !e.isObjective())
                .collect(Collectors.toList());

        // Vincoli ≤
        if (!ineqsLE.isEmpty()) {
            sb.append("\n Gx ≤ h\n");
            for (Expression e : ineqsLE) {
                boolean isRedundant = checkIfRedundant(e);
                sb.append("    [ ");
                for (int c = 0; c < n; c++) {
                    sb.append(String.format("%12.8f ", e.get(vars.get(c)).doubleValue()));
                }
                sb.append("] ≤ [ ");
                sb.append(String.format("%12.8f", e.getUpperLimit().doubleValue()));
                sb.append(" ] (" + e.getName() + ")");
                if (isRedundant) {
                	sb.append(" >>>RIDONDANTE<<<");
                }
                sb.append("\n");
            }
        }

        // Vincoli ≥
        if (!ineqsGE.isEmpty()) {
            sb.append("\n Fx ≥ j\n");
            for (Expression e : ineqsGE) {
                boolean isRedundant = checkIfRedundant(e);
                sb.append("    [ ");
                for (int c = 0; c < n; c++) {
                    sb.append(String.format("%12.8f ", e.get(vars.get(c)).doubleValue()));
                }
                sb.append("] ≥ [ ");
                sb.append(String.format("%12.8f", e.getLowerLimit().doubleValue()));
                sb.append(" ] (" + e.getName() + ")");
                if (isRedundant) {
                	sb.append(" >>>RIDONDANTE<<<");
                }
                sb.append("\n");
            }
        }

        // Vincoli di uguaglianza
        if (!eqs.isEmpty()) {
            sb.append("\n Ax = b\n");
            for (Expression e : eqs) {
                boolean isRedundant = checkIfRedundant(e);
                sb.append("    [ ");
                for (int c = 0; c < n; c++) {
                    sb.append(String.format("%12.8f ", e.get(vars.get(c)).doubleValue()));
                }
                sb.append("] = [ ");
                sb.append(String.format("%12.8f", e.getLowerLimit().doubleValue()));
                sb.append(" ] (" + e.getName() + ")");
                if (isRedundant) {
                	sb.append(" >>>RIDONDANTE<<<");
                }
                sb.append("\n");
            }
        }

        // Bound
        sb.append("\n: Bound\n");
        sb.append("  lb =\n");
        sb.append("    [ ");
        for (int i = 0; i < n; i++) {
        	Variable var = vars.get(i);
            sb.append(var.getLowerLimit() != null ? String.format("%12.8f ",var.getLowerLimit().doubleValue()) : "-inf\t");
        }
        sb.append(" ]\n");
        sb.append("  ub =\n");
        sb.append("    [ ");
        for (int i = 0; i < n; i++) {
        	Variable var = vars.get(i);
            sb.append(var.getUpperLimit() != null ? String.format("%12.8f ",var.getUpperLimit().doubleValue()) : "inf\t");
        }
        sb.append(" ]\n");

        // Vincoli quadratici
        List<Expression> qcs = model.getExpressions().stream()
                .filter(e -> e.isAnyQuadraticFactorNonZero() && e.isConstraint() && !e.isObjective())
                .collect(Collectors.toList());
        Collections.reverse(qcs);
        for (int k = 0; k < qcs.size(); k++) {
            Expression e = qcs.get(k);
            boolean isRedundant = checkIfRedundant(e);
            sb.append("\n: Vincolo quadratico " + (k + 1) + ": (" + e.getName() + ")");
            if (isRedundant) {
            	sb.append(" >>>RIDONDANTE<<<");
            }
            sb.append("\n");
            sb.append("  ½ xᵀ Q_" + (k + 1) + " x + p_" + (k + 1) + "ᵀ x + r_" + (k + 1) + " ≤ 0\n");

            double[][] Qk = new double[n][n];
            double[] pk = new double[n];

            for (Map.Entry<IntIndex, BigDecimal> entry : e.getLinearEntrySet()) {
                pk[entry.getKey().index] = entry.getValue().doubleValue();
            }
            for (Map.Entry<IntRowColumn, BigDecimal> entry : e.getQuadraticEntrySet()) {
                Qk[entry.getKey().row][entry.getKey().column] = APPLICA_12 ? (entry.getValue().doubleValue() * 2) : entry.getValue().doubleValue();//rimetto il *2 che era stato tolto nella creazione del modello
            }

            sb.append("  Q_" + (k + 1) + " =\n");
            appendMatrix(sb, Qk);
            sb.append("  p_" + (k + 1) + " =\n");
            appendVector(sb, pk);
            sb.append("  r_" + (k + 1) + " = ").append(-e.getUpperLimit().doubleValue()).append("\n");
        }

        logger.debug(sb.toString());
    }

    public static void printModelDetailsOLD(Logger logger, ExpressionsBasedModel model) {
        StringBuilder sb = new StringBuilder();

        //ATTENZIONE!! questa print presolve anche per avere le info di ridondanza, è solo a scopo di debug!!!
        model.simplify();
        
        List<Variable> vars = model.getVariables();
//        List<Expression> expressions = model.getExpressions().stream().collect(Collectors.toList());
        int n = vars.size();

        sb.append("\n");
        sb.append(": Problema\n");
        sb.append("  min ½ xᵀQx + pᵀx + r\n");

        Expression obj = model.objective();

        double[][] Q = new double[n][n];
        double[] p = new double[n];

        // Lineare
        for (Map.Entry<IntIndex, BigDecimal> entry : obj.getLinearEntrySet()) {
            int i = entry.getKey().index;
            p[i] = entry.getValue().doubleValue();
        }

        // Quadratica
        for (Map.Entry<IntRowColumn, BigDecimal> entry : obj.getQuadraticEntrySet()) {
            int i = entry.getKey().row;
            int j = entry.getKey().column;
            Q[i][j] = entry.getValue().doubleValue();
        }

        sb.append("  Q =\n");
        appendMatrix(sb, Q);

        sb.append("  p =\n");
        appendVector(sb, p);
        
        //Variabili
        sb.append("\n:Variabili\n");
        for (int i = 0; i < n; ++i) {
        	Variable v = vars.get(i);
        	sb.append("  ["+i+"] : " + v.getName());
        	if (v.isBinary()) {
        		sb.append(" [binary]");
        	}
        	if (checkIfFixed(v)) {
        		sb.append(" >>>FIXED<<< => 0");
        	}
        	sb.append("\n");
        }
        
        // Vincoli lineari <=
        List<Expression> ineqsLE = model.getExpressions().stream().filter(expr -> !expr.isEqualityConstraint() && expr.isConstraint() && expr.getUpperLimit() != null && expr.getLowerLimit() == null && !expr.isAnyQuadraticFactorNonZero() && !expr.isObjective()).collect(Collectors.toList());
        List<Expression> ineqsGE = model.getExpressions().stream().filter(expr -> !expr.isEqualityConstraint() && expr.isConstraint() && expr.getUpperLimit() == null && expr.getLowerLimit() != null && !expr.isAnyQuadraticFactorNonZero() && !expr.isObjective()).collect(Collectors.toList());
        
        List<Expression> eqs = model.getExpressions().stream().filter(expr -> expr.isEqualityConstraint()  && expr.isConstraint() && !expr.isAnyQuadraticFactorNonZero() && !expr.isObjective()).collect(Collectors.toList());

        if (!ineqsLE.isEmpty() || !ineqsGE.isEmpty()) {
        	sb.append("\n:Disuguaglianze");
        }
        if (!ineqsLE.isEmpty()) {
            sb.append("\n Gx ≤ h\n");
            sb.append("  G =\n");
            for (int r = 0; r < ineqsLE.size(); r++) {
                Expression e = ineqsLE.get(r);
                boolean isRedundant = checkIfRedundant(e);
                sb.append("    [ ");
                for (int c = 0; c < n; c++) {
                    double val = e.get(vars.get(c)).doubleValue();
                    sb.append(String.format("%6.2f ", val));
                }
                sb.append("] ("+e.getName()+")");

                if (isRedundant) {
                	sb.append(" >>>RIDONDANTE<<<");
                }
                sb.append("\n");
            }

            sb.append("  h =\n");
            sb.append("    [ ");
            for (Expression e : ineqsLE) {
                sb.append(String.format("%6.2f ", e.getUpperLimit().doubleValue()));
            }
            sb.append("]\n");
        }
        if (!ineqsGE.isEmpty()) {
            sb.append("\n Fx ≥ j\n");
            sb.append("  F =\n");
            for (int r = 0; r < ineqsGE.size(); r++) {
                Expression e = ineqsGE.get(r);
                boolean isRedundant = checkIfRedundant(e);
                sb.append("    [ ");
                for (int c = 0; c < n; c++) {
                    double val = e.get(vars.get(c)).doubleValue();
                    sb.append(String.format("%6.2f ", val));
                }
                sb.append("] ("+e.getName()+")");

                if (isRedundant) {
                	sb.append(" >>>RIDONDANTE<<<");
                }
                sb.append("\n");
            }

            sb.append("  j =\n");
            sb.append("    [ ");
            for (Expression e : ineqsGE) {
                sb.append(String.format("%6.2f ", e.getLowerLimit().doubleValue()));
            }
            sb.append("]\n");
        }

        if (!eqs.isEmpty()) {
            sb.append("\n:Uguaglianze\n Ax = b\n");
            sb.append("  A =\n");
            for (int r = 0; r < eqs.size(); r++) {
                Expression e = eqs.get(r);
                boolean isRedundant = checkIfRedundant(e);
                sb.append("    [ ");
                for (int c = 0; c < n; c++) {
                    double val = e.get(vars.get(c)).doubleValue();
                    sb.append(String.format("%6.2f ", val));
                }
                sb.append("] ("+e.getName()+")");
                if (isRedundant) {
                	sb.append(" >>>RIDONDANTE<<<");
                }
                sb.append("\n");
            }

            sb.append("  b =\n");
            sb.append("    [ ");
            for (Expression e : eqs) {
                sb.append(String.format("%6.2f ", e.getLowerLimit().doubleValue()));
            }
            sb.append("]\n");
        }

        // Bound
        sb.append("\n: Bound\n");
        sb.append("  lb =\n");
        sb.append("    [ ");
        for (int i = 0; i < n; i++) {
        	Variable var = vars.get(i);
            sb.append(var.getLowerLimit() != null ? String.format("%6.2f ",var.getLowerLimit().doubleValue()) : "-inf");
        }
        sb.append(" ]\n");
        sb.append("  ub =\n");
        sb.append("    [ ");
        for (int i = 0; i < n; i++) {
        	Variable var = vars.get(i);
            sb.append(var.getUpperLimit() != null ? String.format("%6.2f ",var.getUpperLimit().doubleValue()) : "inf");
        }
        sb.append(" ]\n");

        // Vincoli quadratici
        List<Expression> qcs = model.getExpressions().stream().filter(expr -> expr.isAnyQuadraticFactorNonZero() && expr.isConstraint() && !expr.isObjective()).collect(Collectors.toList());
        Collections.reverse(qcs);
        for (int k = 0; k < qcs.size(); k++) {
            Expression e = qcs.get(k);
            boolean isRedundant = checkIfRedundant(e);
            sb.append("\n: Vincolo quadratico " + (k + 1) + ": ("+e.getName()+")");
            if (isRedundant) {
            	sb.append(" >>>RIDONDANTE<<<");
            }
            sb.append("\n");
            sb.append("  ½ xᵀ Q_" + (k + 1) + " x + p_" + (k + 1) + "ᵀ x + r_" + (k + 1) + " ≤ 0\n");

            double[][] Qk = new double[n][n];
            double[] pk = new double[n];

            for (Map.Entry<IntIndex, BigDecimal> entry : e.getLinearEntrySet()) {
                pk[entry.getKey().index] = entry.getValue().doubleValue();
            }

            for (Map.Entry<IntRowColumn, BigDecimal> entry : e.getQuadraticEntrySet()) {
                int i = entry.getKey().row;
                int j = entry.getKey().column;
                Qk[i][j] = entry.getValue().doubleValue();
            }

            sb.append("  Q_" + (k + 1) + " =\n");
            appendMatrix(sb, Qk);
            sb.append("  p_" + (k + 1) + " =\n");
            appendVector(sb, pk);
            sb.append("  r_" + (k + 1) + " = ").append(-e.getUpperLimit().doubleValue()).append("\n");
        }


        logger.debug(sb.toString());
    }

    private static void appendVector(StringBuilder sb, double[] v) {
        sb.append("    [ ");
        for (double d : v) {
            sb.append(String.format("%12.8f ", d));
        }
        sb.append("]\n");
    }

    private static void appendMatrix(StringBuilder sb, double[][] M) {
        for (double[] row : M) {
            sb.append("    [ ");
            for (double d : row) {
                sb.append(String.format("%12.8f ", d));
            }
            sb.append("]\n");
        }
    }
    

    private static boolean checkIfRedundant(Expression expr) {
        try {
            Method isRedundantMethod = Expression.class.getDeclaredMethod("isRedundant");
            isRedundantMethod.setAccessible(true);
            return (boolean) isRedundantMethod.invoke(expr);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Errore", e);
        }
    }

    private static boolean checkIfFixed(Variable v) {
        try {
            Method isRedundantMethod = Variable.class.getDeclaredMethod("isFixed");
            isRedundantMethod.setAccessible(true);
            return (boolean) isRedundantMethod.invoke(v);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Errore", e);
        }
    }

/*
    public static void printModelDetails(Logger logger, ExpressionsBasedModel model) {
        StringBuilder sb = new StringBuilder();

        List<Variable> vars = model.getVariables();
        List<Expression> expressions = model.getExpressions().stream().collect(Collectors.toList());

        int n = vars.size();
        sb.append("Dettagli del problema\n");

        // Obiettivo
        sb.append("\n• Obiettivo\n");
        sb.append("  min ½ xᵀQx + pᵀx\n");
        Expression obj = model.getExpression("objective");

        double[][] Q = new double[n][n];
        double[] p = new double[n];

        for (Map.Entry<IntIndex, BigDecimal> entry : obj.getLinearEntrySet()) {
            int i = entry.getKey().index;
            p[i] = entry.getValue().doubleValue();
        }

        for (Map.Entry<IntRowColumn, BigDecimal> entry : obj.getQuadraticEntrySet()) {
            int i = entry.getKey().row;
            int j = entry.getKey().column;
            Q[i][j] = entry.getValue().doubleValue();
        }

        sb.append("  Q =\n");
        appendMatrix(sb, Q);

        sb.append("  p =\n");
        appendVector(sb, p);

        // Vincoli di uguaglianza Ax = b
        sb.append("\n• Vincoli lineari di uguaglianza Ax = b\n");
        for (Expression e : expressions) {
            if (e.getName().startsWith("eq_")) {
                double rhs = e.getLowerLimit().doubleValue();
                sb.append("  ");
                appendExpressionRow(sb, e, vars, false);
                sb.append(" = ").append(rhs).append("\n");
            }
        }

        // Vincoli di disuguaglianza Gx ≤ h
        sb.append("\n• Vincoli lineari di disuguaglianza Gx ≤ h\n");
        for (Expression e : expressions) {
            if (e.getName().startsWith("ineq_")) {
                double rhs = e.getUpperLimit().doubleValue();
                sb.append("  ");
                appendExpressionRow(sb, e, vars, false);
                sb.append(" ≤ ").append(rhs).append("\n");
            }
        }

        // Bound
        sb.append("\n• Bound\n");
        for (int i = 0; i < n; i++) {
            Variable x = vars.get(i);
            double lb = x.getLowerLimit().doubleValue();
            double ub = x.getUpperLimit().doubleValue();
            sb.append(String.format("  %.1f ≤ x_%d ≤ %.1f%n", lb, i + 1, ub));
        }

        // Vincoli quadratici
        sb.append("\n• Vincoli quadratici (se presenti)\n");
        for (Expression e : expressions) {
            if (e.getName().startsWith("qc_")) {
                double rhs = e.getUpperLimit().doubleValue();
                sb.append("  ½ ");
                appendExpressionRow(sb, e, vars, true);
                sb.append(" ≤ ").append(rhs).append("\n");
            }
        }

        logger.debug(sb.toString());
    }

    private static void appendVector(StringBuilder sb, double[] v) {
        sb.append("    [ ");
        for (double d : v) {
            sb.append(String.format("%6.2f ", d));
        }
        sb.append("]\n");
    }

    private static void appendMatrix(StringBuilder sb, double[][] M) {
        for (double[] row : M) {
            sb.append("    [ ");
            for (double d : row) {
                sb.append(String.format("%6.2f ", d));
            }
            sb.append("]\n");
        }
    }

    private static void appendExpressionRow(StringBuilder sb, Expression e, List<Variable> vars, boolean includeQuadratic) {
        boolean first = true;

        // Lineari
        for (int i = 0; i < vars.size(); i++) {
            Variable xi = vars.get(i);
            double coeff = e.get(xi).doubleValue();
            if (coeff != 0.0) {
                if (!first) sb.append(" + ");
                sb.append(String.format("%.2fx_%d", coeff, i + 1));
                first = false;
            }
        }

        // Quadratici
        if (includeQuadratic) {
            for (Map.Entry<IntRowColumn, BigDecimal> entry : e.getQuadraticEntrySet()) {
                int i = entry.getKey().row;
                int j = entry.getKey().column;
                double q = entry.getValue().doubleValue();
                if (q != 0.0) {
                    if (!first) sb.append(" + ");
                    sb.append(String.format("%.2fx_%d x_%d", 0.5 * q, i + 1, j + 1));
                    first = false;
                }
            }
        }

        if (first) {
            sb.append("0");
        }
    }
    */


}

