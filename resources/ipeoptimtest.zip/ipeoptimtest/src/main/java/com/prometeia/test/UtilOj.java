package com.prometeia.test;

import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;
import org.apache.log4j.Logger;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.ExpressionsBasedModelEx;
import org.ojalgo.optimisation.Optimisation;

import com.prometeia.model.OjAlgoModelBuilder;
import com.prometeia.model.OjProblem;

import cern.colt.Arrays;

public class UtilOj {
	private static final Logger logger = Logger.getLogger(UtilOj.class);

	public static OjProblem caricaProblemaMinTev(String root) throws Exception {
		logger.debug("");
		logger.debug("== " + root + " ==");
	    OjProblem p = new OjProblem();

	    // Obiettivo (M^T * x - y)^T * S * (M^T * x - y)
	    p.setM(Util3.loadRealMatrix(root + "objective/M.csv", true));
	    p.setS(Util3.loadRealMatrix(root + "objective/S.csv", true));
	    p.setY(Util3.loadRealVector(root + "objective/y.csv", false));


	    // Vincoli lineari
	    p.setA(Util3.loadRealMatrix(root + "eq_lin/A.csv", true));
	    p.setB(Util3.loadRealVector(root + "eq_lin/b.csv", false));
	    p.setG(Util3.loadRealMatrix(root + "ineq_lin/G.csv", true));
	    p.setH(Util3.loadRealVector(root + "ineq_lin/h.csv", false));

	    // Bound
	    p.setLb(Util3.loadRealVector(root + "bound/xl.csv", false));
	    p.setUb(Util3.loadRealVector(root + "bound/xu.csv", false));

	    // Vincoli quadratici


	    return p;
	}
	
	public static OjProblem caricaProblemaQPQC(String root) throws Exception {
		logger.debug("");
		logger.debug("== " + root + " ==");
	    OjProblem p = new OjProblem();

	    // Obiettivo 1/2 x^T Q x + p^T x + r
	    p.setQ(Util3.loadRealMatrix(root + "objective/Q.csv", true));
	    Path pPath = Paths.get(root + "objective/p.csv");
	    if (Files.exists(pPath)) {
	    	p.setP(Util3.loadRealVector(root + "objective/p.csv", false));
	    } else {
		    p.setP(new org.apache.commons.math3.linear.ArrayRealVector(p.getQ().getRowDimension())); //tutti zeri
	    }
	    
	    Path rPath = Paths.get(root + "objective/r.csv");
	    if (Files.exists(rPath)) {
	        List<String> lines = Files.readAllLines(rPath);
	        if (lines.size() > 0 && !lines.get(0).trim().isEmpty()) {
	            p.setR(Double.parseDouble(lines.get(0).trim()));
	        }
	    }

	    // Vincoli lineari
	    p.setA(Util3.loadRealMatrix(root + "eq_lin/A.csv", true));
	    p.setB(Util3.loadRealVector(root + "eq_lin/b.csv", false));
	    p.setG(Util3.loadRealMatrix(root + "ineq_lin/G.csv", true));
	    p.setH(Util3.loadRealVector(root + "ineq_lin/h.csv", false));

	    // Bound
	    p.setLb(Util3.loadRealVector(root + "bound/lb.csv", false));
	    p.setUb(Util3.loadRealVector(root + "bound/ub.csv", false));

	    // Vincoli quadratici
	    Path quadDir = Paths.get(root + "quad_constraints/");
	    if (Files.exists(quadDir) && Files.isDirectory(quadDir)) {
	        // Trova i prefissi validi (es. Q1.csv, p1.csv, r1.csv → prefisso 1)
	        Map<Integer, RealMatrix> Qis = new TreeMap<>();
	        Map<Integer, RealVector> pis = new TreeMap<>();
	        Map<Integer, Double> ris = new TreeMap<>();

	        try (DirectoryStream<Path> files = Files.newDirectoryStream(quadDir)) {
	            for (Path f : files) {
	                String name = f.getFileName().toString();
	                if (name.matches("[Qpr]\\d+\\.csv")) {
	                    char type = name.charAt(0); // Q, p o r
	                    int idx = Integer.parseInt(name.replaceAll("[^0-9]", ""));
	                    try {
	                        switch (type) {
	                            case 'Q':
	                                Qis.put(idx, Util3.loadRealMatrix(f.toString(), true));
	                                break;
	                            case 'p':
	                                pis.put(idx, Util3.loadRealVector(f.toString(), false));
	                                break;
	                            case 'r':
	                                List<String> lines = Files.readAllLines(f);
	                                ris.put(idx, Double.parseDouble(lines.get(0).trim()));
	                                break;
	                        }
	                    } catch (Exception e) {
	                        throw new RuntimeException("Errore nella lettura di " + name, e);
	                    }
	                }
	            }
	        }


	        if (!Qis.isEmpty() && Qis.keySet().equals(pis.keySet()) && Qis.keySet().equals(ris.keySet())) {
	            List<RealMatrix> QList = new ArrayList<>();
	            List<RealVector> pList = new ArrayList<>();
	            List<Double> rList = new ArrayList<>();
	            for (Integer i : Qis.keySet()) {
	                QList.add(Qis.get(i));
	                pList.add(pis.get(i));
	                rList.add(ris.get(i));
	            }
	            p.setQ_i(QList);
	            p.setP_i(pList);
	            p.setR_i(rList);
	        } else if (!Qis.isEmpty()) {
	            throw new IllegalArgumentException("I vincoli quadratici non sono completi o allineati (Q/p/r)");
	        }
	    }

	    return p;
	}

	
	public static OjProblem caricaProblemaLineare(String root) throws Exception {
	    OjProblem p = new OjProblem();
	    // Obiettivo
	    p.setP(Util3.loadRealVector(root + "FL.csv", true));
	    p.setQ(new org.apache.commons.math3.linear.Array2DRowRealMatrix(p.getP().getDimension(), p.getP().getDimension())); //tutti zeri
	    p.setR(0d);

	    // Vincoli lineari
	    p.setA(Util3.loadRealMatrix(root + "A.csv", true));
	    p.setB(Util3.loadRealVector(root + "b.csv", false));
	    p.setG(Util3.loadRealMatrix(root + "G.csv", true));
	    p.setH(Util3.loadRealVector(root + "h.csv", false));

	    // Bound
	    p.setLb(Util3.loadRealVector(root + "lb.csv", false));
	    p.setUb(Util3.loadRealVector(root + "ub.csv", false));

	    // Vincoli quadratici
//	    Path quadDir = Paths.get(root + "quad_constraints/");
//	    if (Files.exists(quadDir) && Files.isDirectory(quadDir)) {
//	        // Trova i prefissi validi (es. Q1.csv, p1.csv, r1.csv → prefisso 1)
//	        Map<Integer, RealMatrix> Qis = new TreeMap<>();
//	        Map<Integer, RealVector> pis = new TreeMap<>();
//	        Map<Integer, Double> ris = new TreeMap<>();
//
//	        try (DirectoryStream<Path> files = Files.newDirectoryStream(quadDir)) {
//	            for (Path f : files) {
//	                String name = f.getFileName().toString();
//	                if (name.matches("[Qpr]\\d+\\.csv")) {
//	                    char type = name.charAt(0); // Q, p o r
//	                    int idx = Integer.parseInt(name.replaceAll("[^0-9]", ""));
//	                    try {
//	                        switch (type) {
//	                            case 'Q':
//	                                Qis.put(idx, Util3.loadRealMatrix(f.toString(), true));
//	                                break;
//	                            case 'p':
//	                                pis.put(idx, Util3.loadRealVector(f.toString(), false));
//	                                break;
//	                            case 'r':
//	                                List<String> lines = Files.readAllLines(f);
//	                                ris.put(idx, Double.parseDouble(lines.get(0).trim()));
//	                                break;
//	                        }
//	                    } catch (Exception e) {
//	                        throw new RuntimeException("Errore nella lettura di " + name, e);
//	                    }
//	                }
//	            }
//	        }
//
//
//	        if (!Qis.isEmpty() && Qis.keySet().equals(pis.keySet()) && Qis.keySet().equals(ris.keySet())) {
//	            List<RealMatrix> QList = new ArrayList<>();
//	            List<RealVector> pList = new ArrayList<>();
//	            List<Double> rList = new ArrayList<>();
//	            for (Integer i : Qis.keySet()) {
//	                QList.add(Qis.get(i));
//	                pList.add(pis.get(i));
//	                rList.add(ris.get(i));
//	            }
//	            p.setQ_i(QList);
//	            p.setP_i(pList);
//	            p.setR_i(rList);
//	        } else if (!Qis.isEmpty()) {
//	            throw new IllegalArgumentException("I vincoli quadratici non sono completi o allineati (Q/p/r)");
//	        }
//	    }

	    return p;
	}
	
	public static void StampaModello(ExpressionsBasedModelEx mEx) {
		ExpressionsBasedModel model = mEx.getModel();
		ExpressionsBasedModel model1 = model.simplify();
		OjAlgoModelBuilder.printModelDetails(logger, "ORIGINALE", model); //model è stato modificato in place dalla simplify per aggiungere le info di ridondanza
		OjAlgoModelBuilder.printModelDetails(logger, "PRESOLTO", model1); //model1 contiene l'effettiva semplificazione del problema
	}

	public static void printResult(Logger loggerr, Optimisation.Result result, String opt, long ms) {

		if (result == null) {
			return;
		}
		int n = (int)result.count();
        double[] solution = new double[n];

        for (int i = 0; i < n; i++) {
            solution[i] = result.doubleValue(i);
        }
        
//        Optimisation.Result r2 = result.getSolution(NumberContext.of(14, 0));
//        for (int i = 0; i < n; i++) {
//            solution[i] = r2.doubleValue(i);
//        }
        
		// Stampa stato della soluzione
		loggerr.debug("=== Risultato Ottimizzazione "+opt+": "+ms+"ms === ");
		loggerr.debug("Stato:     " + result.getState());
		loggerr.debug("Valore f:  " + result.getValue());
		loggerr.debug(Arrays.toString(solution));
		loggerr.debug("");
	}

}
