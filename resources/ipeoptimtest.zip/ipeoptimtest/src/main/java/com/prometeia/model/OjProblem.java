package com.prometeia.model;

import java.util.List;

import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

/*
 * 
 * min 1/2 x^T Qx + p^T x + r 
 * min (M^T * x - y)^T * QQ * (M^T * x - y)
 * 
 * Gx <= h
 * Ax = b
 * lb <= x <= ub
 * 1/2 x^T Q_i x + x^T p_i + r_i <= 0
 * 
 * 
 */
public class OjProblem {

	
	//f.o formato 1/2 x^T Qx + p^T x + r
	private RealMatrix Q;
	private RealVector p;
	private Double r;
	
	//f.o formato (M^T * x - y)^T * S * (M^T * x - y)
	private RealMatrix M;
	private RealVector y;
	private RealMatrix S;
	
	 
	
	//lineari
	private RealMatrix G;
	private RealMatrix A;
	private RealVector b;
	private RealVector h;
	private RealVector lb;
	private RealVector ub;
	
	//quadratici
	List<RealMatrix> Q_i;
	List<RealVector> p_i;
	List<Double> r_i;
	public RealMatrix getQ() {
		return Q;
	}
	public void setQ(RealMatrix q) {
		Q = q;
	}
	public RealVector getP() {
		return p;
	}
	public void setP(RealVector p) {
		this.p = p;
	}
	public Double getR() {
		return r;
	}
	public void setR(Double r) {
		this.r = r;
	}
	public RealMatrix getG() {
		return G;
	}
	public void setG(RealMatrix g) {
		G = g;
	}
	public RealMatrix getA() {
		return A;
	}
	public void setA(RealMatrix a) {
		A = a;
	}
	public RealVector getB() {
		return b;
	}
	public void setB(RealVector b) {
		this.b = b;
	}
	public RealVector getH() {
		return h;
	}
	public void setH(RealVector h) {
		this.h = h;
	}
	public RealVector getLb() {
		return lb;
	}
	public void setLb(RealVector lb) {
		this.lb = lb;
	}
	public RealVector getUb() {
		return ub;
	}
	public void setUb(RealVector ub) {
		this.ub = ub;
	}
	public List<RealMatrix> getQ_i() {
		return Q_i;
	}
	public void setQ_i(List<RealMatrix> q_i) {
		Q_i = q_i;
	}
	public List<RealVector> getP_i() {
		return p_i;
	}
	public void setP_i(List<RealVector> p_i) {
		this.p_i = p_i;
	}
	public List<Double> getR_i() {
		return r_i;
	}
	public void setR_i(List<Double> r_i) {
		this.r_i = r_i;
	}
	public RealMatrix getM() {
		return M;
	}
	public void setM(RealMatrix m) {
		M = m;
	}
	public RealVector getY() {
		return y;
	}
	public void setY(RealVector y) {
		this.y = y;
	}
	public RealMatrix getS() {
		return S;
	}
	public void setS(RealMatrix s) {
		S = s;
	}
	
	
	
	
	
	
	
}
