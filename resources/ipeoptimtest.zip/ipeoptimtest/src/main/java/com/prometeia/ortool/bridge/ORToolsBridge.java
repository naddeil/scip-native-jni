package com.prometeia.ortool.bridge;

import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealVector;
import org.apache.log4j.Logger;

import com.google.ortools.Loader;
import com.google.ortools.linearsolver.MPConstraint;
import com.google.ortools.linearsolver.MPObjective;
import com.google.ortools.linearsolver.MPQuadraticConstraint;
import com.google.ortools.linearsolver.MPSolver;
import com.google.ortools.linearsolver.MPVariable;
import com.prometeia.model.OptimizationResultInfo;
import com.prometeia.model.OptimizationResultInfo.OptimizationResult;
import com.prometeia.model.Problem;

/**
 * min f(x) s.t.
 * Gx <= h
 * Ax = b
 * x >= 0
 * xl <= x <= xu
 */
public class ORToolsBridge {

	private static final Logger logger = Logger.getLogger(ORToolsBridge.class);
    static {
        Loader.loadNativeLibraries(); 
    }
    
    public static enum Solver { GLOP, SCIP }
    
    public OptimizationResultInfo optimize(Problem problem, Solver s) {

    	long start = System.currentTimeMillis();
    	
        int n = problem.getFL().getDimension();
        MPSolver solver = MPSolver.createSolver(s.toString());
        if (solver == null) {
            return new OptimizationResultInfo(OptimizationResult.ERROR, new double[n], -99.0);
        }

        // Variabili decisionali x_i ∈ [xl_i, xu_i]
        MPVariable[] xVars = new MPVariable[n];
        for (int i = 0; i < n; i++) {
            double lb = (problem.getXl() != null) ? problem.getXl().getEntry(i) : 0.0;
            double ub = (problem.getXu() != null) ? problem.getXu().getEntry(i) : Double.POSITIVE_INFINITY;
            xVars[i] = solver.makeNumVar(lb, ub, "x_" + i);
        }

        // Vincoli di uguaglianza: A x = b
        if (problem.getA() != null && problem.getB() != null) {
            RealMatrix A = problem.getA();
            RealVector b = problem.getB();
            for (int i = 0; i < A.getRowDimension(); i++) {
                MPConstraint c = solver.makeConstraint(b.getEntry(i), b.getEntry(i), "eq_" + i);
                for (int j = 0; j < A.getColumnDimension(); j++) {
                    c.setCoefficient(xVars[j], A.getEntry(i, j));
                }
            }
        }

        // Vincoli di disuguaglianza: G x ≤ h
        if (problem.getG() != null && problem.getH() != null) {
            RealMatrix G = problem.getG();
            RealVector h = problem.getH();
            for (int i = 0; i < G.getRowDimension(); i++) {
                MPConstraint c = solver.makeConstraint(Double.NEGATIVE_INFINITY, h.getEntry(i), "ineq_" + i);
                for (int j = 0; j < G.getColumnDimension(); j++) {
                    c.setCoefficient(xVars[j], G.getEntry(i, j));
                }
            }
        }

        // Crea vincolo quadratico: x^2 + y^2 <= 10
        MPQuadraticConstraint quadConstraint = MPQuadraticConstraint.newBuilder().build(); 
        //quadConstraint.setCoefficient(x, x, 1.0); // x^2
        //quadConstraint.setCoefficient(y, y, 1.0); // y^2
        
        // Funzione obiettivo: min fᵀx
        MPObjective objective = solver.objective();
        for (int i = 0; i < n; i++) {
            objective.setCoefficient(xVars[i], problem.getFL().getEntry(i));
        }
        objective.setMinimization();
        
        if (logger.isDebugEnabled()) {
        	String model = solver.exportModelAsLpFormat(true);
        	logger.debug("Modello LP esportato:\n" + model);
        }

        // Risoluzione
        MPSolver.ResultStatus status = solver.solve();

        double[] solution = new double[n];
        for (int i = 0; i < n; i++) {
            solution[i] = xVars[i].solutionValue();
        }

        OptimizationResult result;
        switch (status) {
            case OPTIMAL:
                result = OptimizationResult.SUCCESS;
                break;
            case FEASIBLE:
                result = OptimizationResult.WARNING;
                break;
            case INFEASIBLE:
            case ABNORMAL:
            case MODEL_INVALID:
                result = OptimizationResult.ERROR;
                break;
            case NOT_SOLVED:
            default:
                result = OptimizationResult.MAXIMUM_ITERATION;
                break;
        }

        logger.debug("tempo totale: "+(System.currentTimeMillis()-start));
        return new OptimizationResultInfo(result, solution, -99.0);
    }
}