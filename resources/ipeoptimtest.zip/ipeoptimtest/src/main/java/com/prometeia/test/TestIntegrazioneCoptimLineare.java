package com.prometeia.test;



import org.apache.log4j.Logger;
import org.ojalgo.optimisation.ExpressionsBasedModel;
import org.ojalgo.optimisation.ExpressionsBasedModelEx;
import org.ojalgo.optimisation.Optimisation;
import org.ojalgo.optimisation.solver.cplex.SolverCPLEX;
import org.ojalgo.optimisation.solver.joptimizer.SolverJOptimizerCustom;
import org.ojalgo.optimization.solver.scip.SolverScipQuad;

import com.prometeia.model.OjAlgoModelBuilder;
import com.prometeia.model.OjProblem;
import com.prometeia.model.OptimizationResultInfo;
import com.prometeia.model.Problem;

public class TestIntegrazioneCoptimLineare {
	private static final Logger logger = Logger.getLogger(TestIntegrazioneCoptimLineare.class);
	
	// aggiungere
	// -Djava.library.path=${workspace_loc:ipeoptimtest}/src/main/resources/cplex211X
	public static void main(String[] args) throws Exception {
	
		//PlainCoptimTestLP("src/test/resources/unitLP_3_rilassato/");
		OjProblem p = UtilOj.caricaProblemaLineare("src/test/resources/unitLP_3_rilassato/");
		/**
		 * unitLP_3: coptim soffre
		 */
		UtilOj.StampaModello(OjAlgoModelBuilder.buildModel12q_p_r(p));
		OjTest(p);
		


	}
	

	
//	public static void OjLinearProblemCoptim(String cartella) throws Exception {
//		
//		
//		long i,f;		
//		OjProblem p = Test.caricaProblemaLineare(cartella);
//		Optimisation.Result result = null;
//		ExpressionsBasedModel model = null;
//		
//        
//        //test Coptim_ojizzato
//		model = OjAlgoModelBuilder.buildModel(p);
//        ExpressionsBasedModel.clearIntegrations();
//		ExpressionsBasedModel.addIntegration(SolverCOptim.INTEGRATION);
//		i = System.currentTimeMillis();
//		result = model.minimise();
//		f = System.currentTimeMillis();
//		
//        Test.print(logger, result,"Coptim_ojizzato", f-i);
//	}
	
	public static void OjTest(OjProblem p) throws Exception {

		long i,f;		
		Optimisation.Result result = null;
		ExpressionsBasedModelEx model = null;
		
		
 		model = OjAlgoModelBuilder.buildModel12q_p_r(p);
        ExpressionsBasedModel.clearIntegrations();
		ExpressionsBasedModel.addIntegration(SolverScipQuad.INTEGRATION);
		i = System.currentTimeMillis();
		result = model.minimise();
		f = System.currentTimeMillis();
		UtilOj.printResult(logger, result,"scip", f-i);
        
	}
	
	public static void OjTestMinTev(OjProblem p) throws Exception {

		long i,f;		
		Optimisation.Result result = null;
		ExpressionsBasedModelEx model = null;
		
		//warm up
		model = OjAlgoModelBuilder.buildModel_minTev(p);
		try {
			result = model.minimise();
		} catch (Exception e) {
			result = null;
		}
        ExpressionsBasedModel.clearIntegrations();
		ExpressionsBasedModel.addIntegration(SolverJOptimizerCustom.INTEGRATION);
		model = OjAlgoModelBuilder.buildModel_minTev(p);
		try {
			result = model.minimise();
		} catch (Exception e) {
			result = null;
		}
        ExpressionsBasedModel.clearIntegrations();
		ExpressionsBasedModel.addIntegration(SolverCPLEX.INTEGRATION);
		model = OjAlgoModelBuilder.buildModel_minTev(p);
		result = model.minimise();
        ExpressionsBasedModel.clearIntegrations();
		ExpressionsBasedModel.addIntegration(SolverScipQuad.INTEGRATION);
		model = OjAlgoModelBuilder.buildModel_minTev(p);
		result = model.minimise();
        ExpressionsBasedModel.clearIntegrations();
		model = OjAlgoModelBuilder.buildModel_minTev(p);
		result = model.minimise();
		//stop
		

		//test ottimizzatore integrato
		model = OjAlgoModelBuilder.buildModel_minTev(p);
        ExpressionsBasedModel.clearIntegrations();
		i = System.currentTimeMillis();
		try {
			result = model.minimise();
		} catch (Exception e) {
			logger.error(e.getMessage());
			result = null;
		}
		f = System.currentTimeMillis();
		UtilOj.printResult(logger, result,"Integrato", f-i);
        
        //test cplex
		model = OjAlgoModelBuilder.buildModel_minTev(p);
        ExpressionsBasedModel.clearIntegrations();
		ExpressionsBasedModel.addIntegration(SolverCPLEX.INTEGRATION);
		i = System.currentTimeMillis();
		result = model.minimise();
		f = System.currentTimeMillis();
		UtilOj.printResult(logger, result,"Cplex", f-i);
//        
		model = OjAlgoModelBuilder.buildModel_minTev(p);
        ExpressionsBasedModel.clearIntegrations();
		ExpressionsBasedModel.addIntegration(SolverScipQuad.INTEGRATION);
		i = System.currentTimeMillis();
		result = model.minimise();
		f = System.currentTimeMillis();
		UtilOj.printResult(logger, result,"scip", f-i);
        
        //test JOptimizer
//		model = OjAlgoModelBuilder.buildModel_minTev(p);
//        ExpressionsBasedModel.clearIntegrations();
//		ExpressionsBasedModel.addIntegration(SolverJOptimizerCustom.INTEGRATION);
//		i = System.currentTimeMillis();
//		try {
//			result = model.minimise();
//		} catch (Exception e) {
//			result = null;
//		}
//		f = System.currentTimeMillis();
//		UtilOj.printResult(logger, result,"JOptimizer", f-i, p);
        
        //test Coptim_ojizzato
		model = OjAlgoModelBuilder.buildModel_minTev(p);
        ExpressionsBasedModel.clearIntegrations();
		i = System.currentTimeMillis();
		result = model.minimise();
		f = System.currentTimeMillis();
		UtilOj.printResult(logger, result,"Coptim", f-i);
	}

}
