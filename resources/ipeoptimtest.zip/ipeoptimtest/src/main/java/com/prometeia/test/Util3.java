package com.prometeia.test;

import java.io.FileReader;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.RealVector;

import com.Ostermiller.util.CSVParser;

public class Util3 {

	public static final RealMatrix loadRealMatrix(String nomeFile, boolean sparse) throws Exception {
		if (!Files.exists(Paths.get(nomeFile))) {
			return null;
		}
		FileReader fr;
		fr = new FileReader(nomeFile);
		CSVParser parser = new CSVParser(fr, ',');
		String[][] mapMatrix = parser.getAllValues();
		RealMatrix ret;
		if(sparse){
			int tot = 0;
			int not0 = 0;
			//ret = new OpenMapRealMatrix(mapMatrix.length, mapMatrix[0].length)
			ret = MatrixUtils.createRealMatrix(mapMatrix.length, mapMatrix[0].length) ;
			for(int i=0; i<mapMatrix.length; i++){
				for(int j=0; j<mapMatrix[0].length; j++){
					tot++;
					double d = Double.parseDouble(mapMatrix[i][j]);
					if(Double.compare(0., d)!=0){
						not0++;
						ret.setEntry(i, j, d);
						//ret.setEntry(i, j, Utils.roundDouble(d, 6))
					} 
				}
			}
//			logger.debug("carico  : "+nomeFile);
//			logger.debug("tot     : "+tot);
//			logger.debug("not zero: "+not0);
		}else{
			double[][] m = new double[mapMatrix.length][mapMatrix[0].length];
			for(int i=0; i<mapMatrix.length; i++){
				for(int j=0; j<mapMatrix[0].length; j++){
					m[i][j] = Double.parseDouble(mapMatrix[i][j]);
					//m[i][j] = Utils.roundDouble(Double.parseDouble(mapMatrix[i][j]), 6)
				}
			}
			ret = MatrixUtils.createRealMatrix(m);
		}
		
		return ret;
	}
	
	public static final RealVector loadRealVector(String nomeFile, boolean sparse) throws Exception {
		if (!Files.exists(Paths.get(nomeFile))) {
			return null;
		}
		FileReader fr;
		fr = new FileReader(nomeFile);
		CSVParser parser = new CSVParser(fr, ',');
		String[][] mapMatrix = parser.getAllValues();
		RealVector ret;
		if(sparse){
			//ret = new OpenMapRealVector(mapMatrix.length)
			ret = new ArrayRealVector(mapMatrix.length) ;
			for(int i=0; i<mapMatrix.length; i++){
				double d = Double.parseDouble(mapMatrix[i][0]);
				if(Double.compare(0., d)!=0){
					ret.setEntry(i, d);
					//ret.setEntry(i, Utils.roundDouble(d, 6))
				} 
			}
		}else{
			double[] v = new double[mapMatrix.length];
			for(int i=0; i<mapMatrix.length; i++){
				v[i] = Double.parseDouble(mapMatrix[i][0]);
				//v[i] = Utils.roundDouble(Double.parseDouble(mapMatrix[i][0]), 6)
			}
			ret = new ArrayRealVector(v);
		}
		
		return ret;
	}
}
