package com.prometeia.test;



import org.apache.log4j.Logger;

import com.prometeia.model.OjAlgoModelBuilder;
import com.prometeia.model.OjProblem;

public class TestIntegrazioneCoptimQuadratico {
	private static final Logger logger = Logger.getLogger(TestIntegrazioneCoptimQuadratico.class);
	
	// aggiungere
	// -Djava.library.path=${workspace_loc:ipeoptimtest}/src/main/resources/cplex211X
	public static void main(String[] args) throws Exception {
	
		OjProblem p = UtilOj.caricaProblemaQPQC("src/test/resources/test_qpqc_simple/");
		/**
		 * test_qp_pure: coptim non va (maximal number of iterations (30) exceeded), scip si addormenta
		 */
		UtilOj.StampaModello(OjAlgoModelBuilder.buildModel12q_p_r(p));

//		for (long i = 0; i < 1000000000; ++i) {
			TestIntegrazioneCoptimLineare.OjTest(p);
//		}
		
		
		

	}
	
}
