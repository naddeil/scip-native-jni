package com.prometeia.model;

import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealVector;

/**
 * Problema in formato Prometeia Modeling Language (PML), cross ottimizzatore
 * 
 * min f(x) s.t.
 * Gx <= h
 * Ax = b
 * x >= 0
 * xl <= x <= xu
 * x^TPx + x^Tq + r <= 0
 */

public class Problem {
	private RealVector FL;//funzione obiettivo lineare
	private RealMatrix A;
	private RealVector B;
	private RealVector H;
	private RealVector xl;
	private RealVector xu;
	
	private RealMatrix K;
	
	//TODO vedere come son lette dal vechcio test
	private int numScenari;// - manu vuole generalizzare?
	private int numAsset;// - manu vuole generalizzare?
	private int numTitoli;// - manu vuole generalizzare?
	

	//---- rendere facoltative??
	private RealVector Y; //ptf modello, da valorizzare opportunamente quando in full
	
	private RealMatrix S; //sigma varcov scenari (per vincolo di tev)
	private double limiteCVaR;
	

	private RealMatrix M; //mappatura titoli
	
	//------------------- facoltative ------------------------
	private RealMatrix G; //disuguaglianze, potrebbero non esserci
	
	
	
	
	private Double limiteRC;
	private Double limiteRCDelta;
	private RealVector D; //peso in mantengo dei titoli, usato in caso di vincolo deltaRC per capire la compoentne mantengo
	private RealMatrix W; //matrice default correlation per RC
	
	
	//m2 -- TODO rivedere questa formilizzazione, e' troppo specifica della vecchia CB
	private RealVector piq;//pesi indicatori qualita
	private Double ts; //tasso sostituzione
	private RealVector costi;
	private Double qualitaOld;
	private Double qualitaAltriBenefici;
	private Double costoOLd;
	private RealVector numerositaImplicite;
	private RealVector scoreQualita;
	private RealVector cedolaProp;
	private RealVector rendimentoAtteso;
	private RealMatrix ME;
	private Double limiteDivImpl;
	private RealVector cvarSuDivImpl;
	private RealMatrix Omega; //varcov titoli distinct
	private Double coeffStDev;
	private RealMatrix MRischio; //mappatura rischio (div implicita titoli distinct->titoli full)
	
	
	public RealVector getFL() {
		return FL;
	}
	public void setFL(RealVector fL) {
		FL = fL;
	}
	public RealMatrix getA() {
		return A;
	}
	public void setA(RealMatrix a) {
		A = a;
	}
	public RealVector getB() {
		return B;
	}
	public void setB(RealVector b) {
		B = b;
	}
	public RealMatrix getG() {
		return G;
	}
	public void setG(RealMatrix g) {
		G = g;
	}
	public RealVector getH() {
		return H;
	}
	public void setH(RealVector h) {
		H = h;
	}
	public RealVector getXl() {
		return xl;
	}
	public void setXl(RealVector xl) {
		this.xl = xl;
	}
	public RealVector getXu() {
		return xu;
	}
	public void setXu(RealVector xu) {
		this.xu = xu;
	}
	public RealMatrix getK() {
		return K;
	}
	public void setK(RealMatrix k) {
		K = k;
	}
	public double getLimiteCVaR() {
		return limiteCVaR;
	}
	public void setLimiteCVaR(double limiteCVaR) {
		this.limiteCVaR = limiteCVaR;
	}
	public Double getLimiteRC() {
		return limiteRC;
	}
	public void setLimiteRC(Double limiteRC) {
		this.limiteRC = limiteRC;
	}
	
	public Double getLimiteRCDelta() {
		return limiteRCDelta;
	}
	public void setLimiteRCDelta(Double limiteRCDelta) {
		this.limiteRCDelta = limiteRCDelta;
	}
	public RealVector getPiq() {
		return piq;
	}
	public void setPiq(RealVector piq) {
		this.piq = piq;
	}
	public Double getTs() {
		return ts;
	}
	public void setTs(Double ts) {
		this.ts = ts;
	}
	public RealVector getCosti() {
		return costi;
	}
	public void setCosti(RealVector costi) {
		this.costi = costi;
	}
	public Double getQualitaOld() {
		return qualitaOld;
	}
	public void setQualitaOld(Double qualitaOld) {
		this.qualitaOld = qualitaOld;
	}
	public Double getQualitaAltriBenefici() {
		return qualitaAltriBenefici;
	}
	public void setQualitaAltriBenefici(Double qualitaAltriBenefici) {
		this.qualitaAltriBenefici = qualitaAltriBenefici;
	}
	public Double getCostoOLd() {
		return costoOLd;
	}
	public void setCostoOLd(Double costoOLd) {
		this.costoOLd = costoOLd;
	}
	public RealVector getNumerositaImplicite() {
		return numerositaImplicite;
	}
	public void setNumerositaImplicite(RealVector numerositaImplicite) {
		this.numerositaImplicite = numerositaImplicite;
	}
	public RealMatrix getME() {
		return ME;
	}
	public void setME(RealMatrix mE) {
		ME = mE;
	}
	public RealVector getScoreQualita() {
		return scoreQualita;
	}
	public void setScoreQualita(RealVector scoreQualita) {
		this.scoreQualita = scoreQualita;
	}
	public RealVector getCedolaProp() {
		return cedolaProp;
	}
	public void setCedolaProp(RealVector cedolaProp) {
		this.cedolaProp = cedolaProp;
	}
	public RealVector getRendimentoAtteso() {
		return rendimentoAtteso;
	}
	public void setRendimentoAtteso(RealVector rendimentoAtteso) {
		this.rendimentoAtteso = rendimentoAtteso;
	}
	public Double getLimiteDivImpl() {
		return limiteDivImpl;
	}
	public void setLimiteDivImpl(Double limiteDivImpl) {
		this.limiteDivImpl = limiteDivImpl;
	}
	public RealVector getCvarSuDivImpl() {
		return cvarSuDivImpl;
	}
	public void setCvarSuDivImpl(RealVector cvarSuDivImpl) {
		this.cvarSuDivImpl = cvarSuDivImpl;
	}
	public RealMatrix getOmega() {
		return Omega;
	}
	public void setOmega(RealMatrix omega) {
		Omega = omega;
	}
	public Double getCoeffStDev() {
		return coeffStDev;
	}
	public void setCoeffStDev(Double coeffStDev) {
		this.coeffStDev = coeffStDev;
	}
	public RealMatrix getS() {
		return S;
	}
	public void setS(RealMatrix s) {
		S = s;
	}
	public RealMatrix getW() {
		return W;
	}
	public void setW(RealMatrix w) {
		W = w;
	}
	public RealMatrix getM() {
		return M;
	}
	public void setM(RealMatrix m) {
		M = m;
	}
	public RealVector getY() {
		return Y;
	}
	public void setY(RealVector y) {
		Y = y;
	}
	public RealVector getD() {
		return D;
	}
	public void setD(RealVector d) {
		D = d;
	}
	public RealMatrix getMRischio() {
		return MRischio;
	}
	public void setMRischio(RealMatrix mRischio) {
		MRischio = mRischio;
	}
	public int getNumScenari() {
		return numScenari;
	}
	public void setNumScenari(int numScenari) {
		this.numScenari = numScenari;
	}
	public int getNumAsset() {
		return numAsset;
	}
	public void setNumAsset(int numAsset) {
		this.numAsset = numAsset;
	}
	public int getNumTitoli() {
		return numTitoli;
	}
	public void setNumTitoli(int numTitoli) {
		this.numTitoli = numTitoli;
	}
	
	
}
