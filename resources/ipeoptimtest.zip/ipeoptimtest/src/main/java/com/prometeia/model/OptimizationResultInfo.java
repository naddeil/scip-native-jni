package com.prometeia.model;

import java.util.Arrays;

public class OptimizationResultInfo {

	private OptimizationResult result;
	private double[]x; //risposta
	private double point; //f(x) test
	private boolean deterministico;
	
	public OptimizationResultInfo(OptimizationResult result, double[] x, double point) {
		this.result = result;
		this.deterministico = false;
		this.x = x;
		this.point = point;
	}

	public OptimizationResult getResult() {
		return result;
	}

	public void setResult(OptimizationResult result) {
		this.result = result;
	}	
	
	public boolean isDeterministico() {
		return deterministico;
	}

	public void setDeterministico(boolean deterministico) {
		this.deterministico = deterministico;
	}
	
	public double[] getX() {
		return x;
	}
	
	public double getPoint() {
		return point;
	}

	@Override
	public String toString() {
		return "result=" + result + ", x= " + Arrays.toString(x) + (deterministico ? " - problema deterministico" : "");
	}	
	
	public static enum OptimizationResult {
		SUCCESS,
		INFEASIBLE,
		MAXIMUM_ITERATION,
		WARNING,
		ERROR
	}
	
}
